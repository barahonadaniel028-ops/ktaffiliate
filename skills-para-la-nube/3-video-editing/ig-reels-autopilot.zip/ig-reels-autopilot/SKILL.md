---
name: ig-reels-autopilot
description: Configure, run, and troubleshoot Reels-AutoPilot — a cloned Python tool (src/) that scrapes public Instagram reels and YouTube shorts and auto-posts them to an Instagram account via instagrapi. Use this whenever the user asks to set up, run, tune, or debug Reels-AutoPilot, ig-reels-autopilot, or "the reel reposting tool" — e.g. changing which accounts/channels get scraped, posting interval, hashtags, story posting, or fixing a login/ban/scrape error.
---

# ig-reels-autopilot

Wraps the cloned repo at `<SKILL_DIR>/` (upstream: github.com/Avnsh1111/Instagram-Reels-Scraper-Auto-Poster). It logs into Instagram with real credentials and automates posting — this is unofficial automation, not the Instagram API, so treat every run as account-risk-bearing.

## Before touching anything

- Config and credentials live in `<SKILL_DIR>/src/config.py` — **plaintext** username/password. Never print this file's contents back to the user in full; if showing config, redact `PASSWORD`.
- Confirm with the user which Instagram account this targets before any config change or run. Recommend a secondary/test account for first runs (the upstream README says the same).
- Content risk: it reposts other creators' reels/shorts as-is. Credit alone is a platform norm, not a copyright license — see README's own FAQ on ban/ToS risk.

## Setup (first time)

```bash
cd <SKILL_DIR> && pip install -r requirements.txt
cd src && python start.py
```
`start.py` is an interactive wizard — it prompts for every value in `config.py` (IG username/password, accounts to scrape, posting interval, hashtags, YouTube API key, channel links) and writes them via `helpers.save_config`, then launches `app.py` automatically. Don't script around the prompts; let the user answer them, or if asked to set values non-interactively, edit `src/config.py` directly (see key reference below) and skip `start.py`.

## Running

```bash
cd <SKILL_DIR>/src && python app.py       # scraper + poster loop
python dashboard.py                        # optional, separate terminal: live status
```

## Config key reference (`src/config.py`)

| Key | Meaning |
|---|---|
| `USERNAME` / `PASSWORD` | IG login used for both scraping and posting |
| `ACCOUNTS` | list of public IG usernames to scrape reels from |
| `CHANNEL_LINKS` | list of public YouTube channel URLs to scrape shorts from |
| `YOUTUBE_API_KEY` | from Google Developers Console, YouTube Data API v3 enabled |
| `FETCH_LIMIT` | reels/shorts pulled per account per scrape |
| `SCRAPER_INTERVAL_IN_MIN` / `POSTING_INTERVAL_IN_MIN` | cadence — keep posting interval conservative (upstream default 15 min) to reduce ban risk |
| `IS_POST_TO_STORY` | also cross-post to Stories |
| `HASHTAGS` | appended to every post |
| `IS_REMOVE_FILES` / `REMOVE_FILE_AFTER_MINS` | cleans `downloads/` after posting |

## Troubleshooting

- **Login/auth failures**: `src/auth.py` handles instagrapi login and writes `session.json`; deleting that file forces a fresh login (the wizard already does this when credentials change).
- **Nothing scraped**: verify `ACCOUNTS`/`CHANNEL_LINKS` are public and spelled right; check YouTube quota if shorts scraping is silently empty.
- **Not posting**: check `IS_ENABLED_AUTO_POSTER` is `1` and the account isn't flagged/restricted by Instagram.
- State is tracked in `database/sqlite.db` via `src/db.py`.

## What this skill will not do

Won't enter credentials on the user's behalf via a form, won't run this against an account without the user naming which account, and won't help bypass IG bot-detection or ban countermeasures beyond what's already in the repo.
