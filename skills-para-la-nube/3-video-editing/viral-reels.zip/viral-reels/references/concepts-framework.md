# Turning a competitor breakdown into new concepts

Read this after `analysis.md` exists. The goal is adaptation, not imitation — the
reference video proves that a *structure* works for this audience; your job is to
carry that structure into the brand's world with a sharper hook.

## What you need before writing

If any of these is missing, ask for it. Concepts written without brand context are
generic and the user will bin them.

- **Who the brand is** — the person or company, what they sell, their credibility marker.
- **Who the viewer is** — the buyer, not the follower. What are they afraid of, what do they want.
- **Tone and constraints** — what they will and won't say on camera, budget, whether the founder appears.
- **The goal** — reach, leads, or sales. This changes how hard the CTA lands.

## The adaptation move

For each reference video, work in this order:

1. **Extract the transferable core** — the underlying tension (e.g. "the thing everyone
   does is quietly costing them money"), stripped of the reference's topic.
2. **Re-anchor it in the brand's domain** — what is the equivalent expensive mistake,
   hidden advantage, or status anxiety for *this* audience?
3. **Rewrite the hook from scratch.** This is where most of the value is. The reference's
   hook is a template for *mechanism* (contradiction, callout, loss), not for wording.
4. **Keep the retention skeleton** — same open loop placement, same delayed payoff, same
   escalation rhythm. This is the part that is genuinely proven; don't redesign it.
5. **Check the reward still lands** — the viewer must end up with something they didn't
   have 30 seconds ago.

## Output format

Produce **3 concepts per reference video** by default, each in this shape. Give the
concepts different hook mechanisms — three variations on one hook is one concept, not three.

```
### Concept N — [3-6 word working title]

**Inspired by:** @creator, [views] views — [one line on what was borrowed]
**Hook mechanism:** [curiosity gap / loss aversion / identity callout / contradiction / status]

**Hook (0-3s)**
- VISUAL: ...
- TEXT ON SCREEN: [max 8 words]
- SPOKEN: "[exact first line]"

**Script**
[Full spoken script, short sentences, written the way a person actually talks.
Mark beats: (hook) (tension) (stakes) (payoff) (close).]

**Retention beats:** [where the open loop opens and closes, where the escalations land]
**Reward:** [what the viewer walks away with]
**Production:** [shot type, location, props, rough effort — 1 line]
**Why this should work for this brand:** [1-2 sentences tying it to the buyer]
```

## Quality bar

Before handing concepts over, check each one against these — they're the failure modes
that make AI-generated video ideas feel useless:

- Would the first spoken line survive being read aloud with no context? If it needs a
  set-up sentence, it isn't a hook.
- Is the concept about the *viewer's* problem, or about the brand? Brand-first concepts
  don't travel.
- Could a competitor post this same script unchanged? If yes, it isn't anchored enough.
- Is it actually shootable with the brand's stated constraints, or does it assume a crew?
- Are the three concepts genuinely different, or the same idea with three thumbnails?

Close by pointing out any **pattern across the reference set** — if four of five top
videos used the same hook mechanism or format, that pattern is worth more to the user
than any single concept.
