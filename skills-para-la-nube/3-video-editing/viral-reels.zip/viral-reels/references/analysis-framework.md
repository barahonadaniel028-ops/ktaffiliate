Watch this video and break it down using the exact structure below. You are reverse-engineering *why it got views*, not summarizing what happens in it.

# CONCEPT

Overall description of the concept of this video, and what makes it valuable and interesting (1-3 sentences).
-> Clarify the core tension: what belief is challenged, what mistake is exposed, or what outcome is promised.
-> One clear idea only. No subtopics.

# HOOK

Detailed description of the first 5 seconds — what makes it scroll-stopping, why a viewer has to stop (1-3 sentences).
-> Break it down into:
- VISUAL (what is seen in the first 1-2 seconds: movement, facial expression, contrast, pattern break)
- TEXT (short on-screen statement: danger, promise, or contradiction, max 6-8 words)
- AUDIO (first spoken words: confident, direct, no intro, no context)
-> The hook must create fear of loss, strong curiosity, or identity relevance. Say which one it uses.

# RETENTION MECHANISMS

How the creator holds attention through the video (1-7 sentences).
-> Open loops ("in a second I'll show you why...", "most people miss this part...")
-> Delayed payoff (the main insight is intentionally held back)
-> Micro-escalations every 3-5 seconds (new angle, sharper wording, visual or tonal shift)
-> Pattern interrupts (pauses, emphasis, cut, zoom, gesture)
-> Clear forward momentum: the viewer feels the video is going somewhere.

# REWARD

The ultimate value the viewer gets for watching (1-3 sentences).
-> Be explicit: what does the viewer now understand, feel, or see differently?
-> Say whether the reward is Education (clarity), Entertainment (emotional release), or Inspiration (self-belief / action).
-> The reward should feel proportional to the time invested.

# SCRIPT

The full script of the video (1-20 sentences, as many as needed).
-> Structure:
1. Immediate hook (no greeting)
2. Problem framing / tension escalation
3. Why this matters (stakes)
4. Main insight or shift in perspective — this comes AFTER retention is established
5. Clean close (no rambling; CTA only if it feels natural)
-> Include scenes, actions, voiceover, and exact wording where you can make it out.
-> Short sentences. Spoken language only.

# PRODUCTION NOTES

Format and craft signals a creator would need to match this (1-5 bullets).
-> Shot type (talking head, b-roll, screen recording, on-location), edit pace, captions style, music, text-on-screen density, apparent production cost.

OVERALL RULE:
THE SHORTER THE ANALYSIS — THE BETTER.
If it can be said in fewer words, it should be.
Clarity > cleverness. Retention > information.
Start your answer directly with the `# CONCEPT` heading — no preamble.
