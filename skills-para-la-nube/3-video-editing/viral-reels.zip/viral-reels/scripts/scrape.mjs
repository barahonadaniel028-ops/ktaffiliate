#!/usr/bin/env node
/**
 * Step 1 — scrape competitor Instagram Reels and keep only the top performers.
 *
 * Usage:
 *   node scrape.mjs --creators handle1,handle2 --days 30 --top 3 --out ./reels-run
 *
 * Writes <out>/reels.json and prints a human-readable summary.
 */
import { mkdirSync, writeFileSync } from "node:fs";
import { join, resolve } from "node:path";
import { parseArgs } from "node:util";
import { loadEnv, requireEnv } from "./lib/env.mjs";
import { scrapeProfile, toReel, rankTopReels } from "./lib/apify.mjs";

const DEFAULTS = { days: 30, top: 3, max: 50, out: "./reels-run", resultsType: "posts" };

function parseOptions() {
  const { values } = parseArgs({
    options: {
      creators: { type: "string" },
      days: { type: "string" },
      top: { type: "string" },
      max: { type: "string" },
      out: { type: "string" },
      "results-type": { type: "string" },
      env: { type: "string" },
    },
  });

  const creators = (values.creators || "")
    .split(",")
    .map((handle) => handle.trim().replace(/^@/, ""))
    .filter(Boolean);

  if (creators.length === 0) {
    throw new Error("Pass --creators with at least one Instagram handle.");
  }

  return {
    creators,
    days: Number(values.days ?? DEFAULTS.days),
    topK: Number(values.top ?? DEFAULTS.top),
    maxPosts: Number(values.max ?? DEFAULTS.max),
    outDir: resolve(values.out ?? DEFAULTS.out),
    resultsType: values["results-type"] ?? DEFAULTS.resultsType,
    envPath: values.env ?? ".env",
  };
}

async function scrapeOne({ token, username, maxPosts, days, topK, resultsType }) {
  const items = await scrapeProfile({ token, username, maxPosts, days, resultsType });
  const reels = items.map((item) => toReel(item, username)).filter(Boolean);
  const top = rankTopReels(reels, { days, topK });
  console.log(`@${username}: ${items.length} items -> ${reels.length} reels -> top ${top.length}`);
  return top;
}

async function main() {
  const options = parseOptions();
  const env = loadEnv(options.envPath);
  const token = requireEnv(
    env,
    "APIFY_API_TOKEN",
    "Get one at https://console.apify.com/account/integrations"
  );

  console.log(
    `Scraping ${options.creators.length} creator(s), last ${options.days} days, top ${options.topK} each.`
  );

  const settled = await Promise.allSettled(
    options.creators.map((username) =>
      scrapeOne({
        token,
        username,
        maxPosts: options.maxPosts,
        days: options.days,
        topK: options.topK,
        resultsType: options.resultsType,
      })
    )
  );

  const reels = [];
  const errors = [];

  settled.forEach((result, index) => {
    if (result.status === "fulfilled") {
      reels.push(...result.value);
      return;
    }
    const message = `@${options.creators[index]}: ${result.reason?.message ?? result.reason}`;
    errors.push(message);
    console.error(`FAILED ${message}`);
  });

  reels.sort((a, b) => b.views - a.views);

  mkdirSync(options.outDir, { recursive: true });
  const outFile = join(options.outDir, "reels.json");
  writeFileSync(
    outFile,
    JSON.stringify(
      { scrapedAt: new Date().toISOString(), params: options, errors, reels },
      null,
      2
    )
  );

  console.log(`\n${reels.length} reels selected -> ${outFile}`);
  for (const reel of reels) {
    console.log(`  ${reel.views.toLocaleString().padStart(10)} views  @${reel.username}  ${reel.postUrl}`);
  }

  if (reels.length === 0) {
    console.error(
      "\nNo reels found. Check the handles, widen --days, or confirm the accounts are public."
    );
    process.exitCode = 1;
  }
}

main().catch((error) => {
  console.error(`\nScrape failed: ${error.message}`);
  process.exit(1);
});
