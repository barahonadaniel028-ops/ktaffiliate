#!/usr/bin/env python3
"""
Step 2b — quantitative layer over a scraped reel corpus.

Compares the top decile against the bottom decile to find which words, hashtags,
CTAs and themes actually correlate with reach, instead of eyeballing the winners.
Winners-only analysis is the classic survivorship trap: a word that appears in
every top reel is worthless if it also appears in every flop.

Usage:
    python3 corpus-report.py --input reels-run/full/reels.json --out reels-run/full
"""
import argparse
import json
import re
import statistics as stats
from collections import Counter
from pathlib import Path

STOPWORDS = {
    "the", "a", "an", "and", "or", "but", "if", "to", "of", "in", "on", "for",
    "with", "at", "by", "from", "up", "out", "is", "it", "its", "this", "that",
    "these", "those", "as", "be", "are", "was", "were", "been", "being", "have",
    "has", "had", "do", "does", "did", "will", "would", "can", "could", "should",
    "you", "your", "yours", "i", "me", "my", "we", "our", "they", "them", "their",
    "he", "she", "his", "her", "not", "no", "so", "what", "when", "how", "why",
    "who", "all", "any", "more", "most", "just", "than", "then", "there", "here",
    "get", "got", "one", "about", "into", "over", "s", "t", "re", "ve", "ll", "m",
    "de", "la", "el", "que", "y", "en", "los", "las", "un", "una", "es", "por",
    "para", "con", "se", "lo", "del", "al", "su", "mi", "te", "me", "no", "si",
}

# Phrases that signal an explicit ask. Grouped so near-synonyms roll up.
CTA_PATTERNS = {
    "comment-to-get": r"\bcomment\s+[\"“']?\w+|\bcomenta\b|\bdrop\s+a\s+comment",
    "link-in-bio": r"\blink\s+in\s+(my\s+)?bio\b|\benlace\s+en\s+(la\s+)?bio",
    "dm-me": r"\bdm\s+me\b|\bsend\s+me\s+a\s+dm\b|\bmand[aá]me\b",
    "follow": r"\bfollow\b|\bs[ií]gueme\b|\bsigue\b",
    "save-share": r"\bsave\s+this\b|\bshare\s+this\b|\bguarda\b|\bcomparte\b",
    "watch-full": r"\bfull\s+(video|episode)\b|\bwatch\s+(the\s+)?full\b|\bv[ií]deo\s+completo",
    "buy-signup": r"\bbuy\b|\border\b|\bsign\s?up\b|\bregist(er|ro)\b|\bcompra\b",
}

# Coarse topic buckets. Deliberately overlapping — a reel can be money AND mindset.
THEMES = {
    "money-wealth": r"\b(money|wealth|rich|millionaire|billion|income|cash|broke|dinero|riqueza|rico|millonario)\b",
    "manifestation": r"\b(manifest\w*|law\s+of\s+attraction|universe|vibration|energy|frequency|manifest\w*|universo|energ[ií]a)\b",
    "mindset-belief": r"\b(mindset|belief|believe|subconscious|mind|think|thought|mente|creencia|pensar)\b",
    "health-cure": r"\b(health|cure|disease|cancer|diet|weight|heal\w*|salud|cura|enfermedad|peso)\b",
    "conspiracy-secret": r"\b(secret|hidden|they\s+don'?t\s+want|suppress\w*|elite|brotherhood|conspir\w*|secreto|oculto)\b",
    "success-habits": r"\b(habit|routine|discipline|morning|goal|success|h[aá]bito|rutina|disciplina|meta|[eé]xito)\b",
    "celebrity-proof": r"\b(jackson|einstein|tesla|rockefeller|jobs|musk|oprah|celebrity|billionaire)\b",
    "authority-story": r"\b(prison|jail|court|fbi|ftc|lawsuit|sentenced|c[aá]rcel|prisi[oó]n)\b",
}

HASHTAG = re.compile(r"#\w+")
WORD = re.compile(r"[a-záéíóúñü']+", re.IGNORECASE)


def load_reels(path):
    data = json.loads(Path(path).read_text())
    reels = data["reels"] if isinstance(data, dict) else data
    return [r for r in reels if r.get("views")]


def tokenize(text):
    return [w for w in WORD.findall(text.lower()) if w not in STOPWORDS and len(w) > 2]


def lift_table(top, bottom, extract, min_count=4):
    """
    Rate of a feature in the top decile vs the bottom decile.
    Lift > 1 means the feature is over-represented among winners.
    """
    top_counts, bottom_counts = Counter(), Counter()
    for reel in top:
        top_counts.update(set(extract(reel)))
    for reel in bottom:
        bottom_counts.update(set(extract(reel)))

    rows = []
    for feature, hits in top_counts.items():
        if hits < min_count:
            continue
        top_rate = hits / len(top)
        bottom_rate = bottom_counts[feature] / len(bottom)
        # Smooth so a zero denominator does not produce infinite lift.
        lift = top_rate / (bottom_rate + 1 / len(bottom))
        rows.append({
            "feature": feature,
            "top_hits": hits,
            "top_rate": round(top_rate, 3),
            "bottom_hits": bottom_counts[feature],
            "bottom_rate": round(bottom_rate, 3),
            "lift": round(lift, 2),
        })
    return sorted(rows, key=lambda r: r["lift"], reverse=True)


def matches(patterns):
    def extract(reel):
        caption = reel.get("caption", "").lower()
        return [name for name, pattern in patterns.items() if re.search(pattern, caption)]
    return extract


def median_views_by(reels, patterns):
    """Median views of reels matching each pattern vs those that don't."""
    rows = []
    for name, pattern in patterns.items():
        hit = [r["views"] for r in reels if re.search(pattern, r.get("caption", "").lower())]
        miss = [r["views"] for r in reels if not re.search(pattern, r.get("caption", "").lower())]
        if len(hit) < 5:
            continue
        rows.append({
            "feature": name,
            "n": len(hit),
            "median_views_with": int(stats.median(hit)),
            "median_views_without": int(stats.median(miss)) if miss else 0,
            "ratio": round(stats.median(hit) / stats.median(miss), 2) if miss else 0,
        })
    return sorted(rows, key=lambda r: r["ratio"], reverse=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--out", default=".")
    parser.add_argument("--decile", type=float, default=0.2,
                        help="fraction treated as top/bottom band (default 0.2)")
    args = parser.parse_args()

    reels = sorted(load_reels(args.input), key=lambda r: r["views"], reverse=True)
    band = max(5, int(len(reels) * args.decile))
    top, bottom = reels[:band], reels[-band:]

    views = [r["views"] for r in reels]
    report = {
        "corpus": {
            "n_reels": len(reels),
            "date_range": [min(r["datePosted"] for r in reels), max(r["datePosted"] for r in reels)],
            "median_views": int(stats.median(views)),
            "mean_views": int(stats.mean(views)),
            "max_views": max(views),
            "band_size": band,
            "top_band_min_views": top[-1]["views"],
            "bottom_band_max_views": bottom[0]["views"],
        },
        "themes_by_lift": lift_table(top, bottom, matches(THEMES), min_count=3),
        "themes_by_median_views": median_views_by(reels, THEMES),
        "ctas_by_lift": lift_table(top, bottom, matches(CTA_PATTERNS), min_count=2),
        "ctas_by_median_views": median_views_by(reels, CTA_PATTERNS),
        "words_by_lift": lift_table(
            top, bottom, lambda r: tokenize(HASHTAG.sub("", r.get("caption", ""))), min_count=4
        )[:40],
        "hashtags_by_lift": lift_table(
            top, bottom, lambda r: [h.lower() for h in HASHTAG.findall(r.get("caption", ""))], min_count=3
        )[:30],
        "caption_length": {
            "top_band_median_chars": int(stats.median([len(r.get("caption", "")) for r in top])),
            "bottom_band_median_chars": int(stats.median([len(r.get("caption", "")) for r in bottom])),
        },
        "top_20_reels": [
            {"views": r["views"], "likes": r["likes"], "comments": r["comments"],
             "date": r["datePosted"], "url": r["postUrl"],
             "caption": r.get("caption", "")[:200]}
            for r in reels[:20]
        ],
    }

    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / "corpus-report.json"
    out_path.write_text(json.dumps(report, indent=2, ensure_ascii=False))

    c = report["corpus"]
    print(f"{c['n_reels']} reels | median {c['median_views']:,} views | "
          f"top band >={c['top_band_min_views']:,} | bottom band <={c['bottom_band_max_views']:,}")
    print(f"Wrote {out_path}")


if __name__ == "__main__":
    main()
