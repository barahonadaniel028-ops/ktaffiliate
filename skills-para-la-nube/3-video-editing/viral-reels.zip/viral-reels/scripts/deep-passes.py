#!/usr/bin/env python3
"""
Computes the numeric side of the seven passes in references/master-prompt.md.

Emits a compact text report meant to be read by the model writing the playbook,
not by a human — it front-loads the contrasts (top band vs bottom band) so the
narrative can be written without re-querying the corpus.

Usage:
    python3 deep-passes.py --input reels-run/full/reels.json --out reels-run/full/passes.txt
"""
import argparse
import datetime
import json
import re
import statistics as stats
from collections import defaultdict

BAND_FRACTION = 0.2

SECOND_PERSON = re.compile(r"\b(you|your|you're|tu|tus|te|usted)\b", re.I)
ALLCAPS_WORD = re.compile(r"\b[A-Z]{3,}\b")
HAS_DIGIT = re.compile(r"\d")

HOOK_MECHANISMS = {
    "curiosity-gap": r"here'?s why|this is|the reason|didn'?t know|reveals?|find out|watch this",
    "contrarian-negation": r"\bnot\b|\bnever\b|\bstop\b|isn'?t|don'?t|instead of|forget ",
    "mundane-specific": r"\b(ink|pen|paper|cursive|waiter|room|watch|rolex|shoe|water|salt|mirror|wallet|shower|bed|coffee|door|chair)\b",
    "borrowed-authority": r"\b(jackson|einstein|tesla|rockefeller|jobs|musk|oprah|bond|elvis|kennedy|napoleon|hill|carnegie|disney)\b",
    "suppression": r"they (don'?t|buried|hid|keep)|hidden|banned|censor|suppress|classified|secret|cover ?up",
    "identity-callout": r"^if you|you'?re the|people who|those who|si (eres|sos)",
    "loss-cost": r"costing you|losing|mistake|wrong|broke|poor|fail",
    "number-timeframe": r"\d+\s*(x|days?|hours?|minutes?|weeks?|months?|years?|%)",
}


def first_line(reel):
    return reel.get("caption", "").split("\n")[0].strip()


def pct(predicate, items):
    return 100 * sum(1 for x in items if predicate(x)) / len(items) if items else 0


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--out", required=True)
    args = parser.parse_args()

    data = json.load(open(args.input))
    reels = sorted(data["reels"], key=lambda x: x["views"], reverse=True)
    n = len(reels)
    band = max(5, int(n * BAND_FRACTION))
    top, bottom = reels[:band], reels[-band:]
    views = [x["views"] for x in reels]
    out = []

    out.append("== PASS 1 — SHAPE ==")
    out.append(
        f"n={n} median={stats.median(views):,.0f} p90={sorted(views)[int(n * .9)]:,} "
        f"max={max(views):,} min={min(views):,} max/median={max(views) / stats.median(views):.1f}x"
    )
    by_month = defaultdict(list)
    for reel in reels:
        by_month[reel["datePosted"][:7]].append(reel["views"])
    out.append("month | n | median | p25(floor) | max")
    for month in sorted(by_month):
        vals = sorted(by_month[month])
        out.append(
            f"  {month} {len(vals):>3} {stats.median(vals):>9,.0f} "
            f"{vals[len(vals) // 4]:>9,} {max(vals):>10,}"
        )

    out.append("\n== PASS 2 — HOOK TAXONOMY (caption-derived) ==")
    out.append("mechanism | top_n | bot_n | lift | median_views_with | n_corpus")
    for name, pattern in HOOK_MECHANISMS.items():
        rx = re.compile(pattern, re.I)
        t = sum(1 for x in top if rx.search(first_line(x)))
        b = sum(1 for x in bottom if rx.search(first_line(x)))
        hit = [x["views"] for x in reels if rx.search(first_line(x))]
        lift = (t / band) / ((b / band) + (1 / band))
        median_hit = stats.median(hit) if hit else 0
        out.append(f"  {name:<22} {t:>3} {b:>3} {lift:>5.2f} {median_hit:>10,.0f} {len(hit):>4}")

    out.append("\n== PASS 3 — LANGUAGE (first line) ==")
    for label, group in (("TOP", top), ("BOT", bottom)):
        lines = [first_line(x) for x in group]
        lines = [x for x in lines if x]
        if not lines:
            continue
        out.append(
            f"{label}: n={len(lines)} "
            f"chars_med={stats.median([len(x) for x in lines]):.0f} "
            f"words_med={stats.median([len(x.split()) for x in lines]):.0f}"
        )
        out.append(
            f"   excl%={pct(lambda x: '!' in x, lines):.0f} "
            f"quest%={pct(lambda x: '?' in x, lines):.0f} "
            f"2nd_person%={pct(lambda x: SECOND_PERSON.search(x), lines):.0f} "
            f"ALLCAPS%={pct(lambda x: ALLCAPS_WORD.search(x), lines):.0f} "
            f"has_number%={pct(lambda x: HAS_DIGIT.search(x), lines):.0f}"
        )

    out.append("\n== PASS 5 — REACH vs RESPONSE ==")
    for label, group in (("TOP", top), ("BOT", bottom)):
        like_rate = [x["likes"] / x["views"] for x in group if x["views"]]
        comment_rate = [x["comments"] / x["views"] for x in group if x["views"]]
        out.append(
            f"{label}: like_rate_median={100 * stats.median(like_rate):.2f}%  "
            f"comment_rate_median={100 * stats.median(comment_rate):.3f}%"
        )

    out.append("\n== PASS 7 — CADENCE ==")
    by_dow = defaultdict(list)
    for reel in reels:
        day = datetime.date.fromisoformat(reel["datePosted"]).strftime("%a")
        by_dow[day].append(reel["views"])
    for day in ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]:
        vals = by_dow.get(day, [])
        out.append(f"  {day} n={len(vals):>3} median={stats.median(vals) if vals else 0:>9,.0f}")

    out.append("\n== TOP 30 FIRST LINES ==")
    for reel in reels[:30]:
        out.append(f"  {reel['views']:>9,} | {first_line(reel)[:90]}")

    out.append("\n== BOTTOM 20 FIRST LINES ==")
    for reel in reels[-20:]:
        out.append(f"  {reel['views']:>9,} | {first_line(reel)[:90]}")

    open(args.out, "w").write("\n".join(out))
    print(f"Wrote {args.out} ({len(out)} lines)")


if __name__ == "__main__":
    main()
