#!/usr/bin/env node
/**
 * Step 2 — send each selected reel to Gemini for a structured breakdown.
 *
 * Usage:
 *   node analyze.mjs --input ./reels-run/reels.json --out ./reels-run
 *
 * Writes <out>/analysis.md (read this next) and <out>/analyses.json.
 */
import { mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { parseArgs } from "node:util";
import { loadEnv, requireEnv } from "./lib/env.mjs";
import {
  downloadVideo,
  uploadVideo,
  analyzeVideo,
  mapWithConcurrency,
} from "./lib/gemini.mjs";

const SCRIPT_DIR = dirname(fileURLToPath(import.meta.url));
const DEFAULT_PROMPT = join(SCRIPT_DIR, "..", "references", "analysis-framework.md");
const DEFAULT_CONCURRENCY = 3;

function parseOptions() {
  const { values } = parseArgs({
    options: {
      input: { type: "string" },
      out: { type: "string" },
      prompt: { type: "string" },
      model: { type: "string" },
      concurrency: { type: "string" },
      env: { type: "string" },
    },
  });

  if (!values.input) throw new Error("Pass --input pointing at reels.json from scrape.mjs.");

  const inputPath = resolve(values.input);
  return {
    inputPath,
    outDir: resolve(values.out ?? dirname(inputPath)),
    promptPath: resolve(values.prompt ?? DEFAULT_PROMPT),
    model: values.model,
    concurrency: Number(values.concurrency ?? DEFAULT_CONCURRENCY),
    envPath: values.env ?? ".env",
  };
}

async function analyzeReel({ reel, apiKey, model, prompt }) {
  const label = `@${reel.username} (${reel.views.toLocaleString()} views)`;
  try {
    console.log(`${label}: downloading`);
    const { buffer, mimeType } = await downloadVideo(reel.videoUrl);

    console.log(`${label}: uploading to Gemini (${(buffer.length / 1e6).toFixed(1)} MB)`);
    const file = await uploadVideo({ apiKey, buffer, mimeType });

    console.log(`${label}: analyzing`);
    const analysis = await analyzeVideo({
      apiKey,
      model,
      fileUri: file.uri,
      mimeType: file.mimeType,
      prompt,
    });

    console.log(`${label}: done`);
    return { ...reel, analysis, error: null };
  } catch (error) {
    console.error(`${label}: FAILED — ${error.message}`);
    return { ...reel, analysis: null, error: error.message };
  }
}

function renderMarkdown(results, { promptPath }) {
  const analyzed = results.filter((r) => r.analysis);
  const failed = results.filter((r) => r.error);

  const header = [
    "# Viral Reels — competitor analysis",
    "",
    `Analyzed ${analyzed.length} of ${results.length} reels on ${new Date().toISOString().slice(0, 10)}.`,
    `Analysis framework: \`${promptPath}\``,
    "",
  ];

  const sections = analyzed.map((reel, index) => {
    const engagement = [
      `- Views: ${reel.views.toLocaleString()}`,
      `- Likes: ${reel.likes.toLocaleString()}  |  Comments: ${reel.comments.toLocaleString()}`,
      `- Posted: ${reel.datePosted}`,
      `- Link: ${reel.postUrl}`,
    ].join("\n");

    return [
      `---`,
      "",
      `## ${index + 1}. @${reel.username} — ${reel.views.toLocaleString()} views`,
      "",
      engagement,
      "",
      reel.analysis,
      "",
    ].join("\n");
  });

  const failures = failed.length
    ? [
        "---",
        "",
        "## Failed",
        "",
        ...failed.map((reel) => `- @${reel.username} ${reel.postUrl} — ${reel.error}`),
        "",
      ]
    : [];

  return [...header, ...sections, ...failures].join("\n");
}

async function main() {
  const options = parseOptions();
  const env = loadEnv(options.envPath);
  const apiKey = requireEnv(
    env,
    "GEMINI_API_KEY",
    "Get one at https://aistudio.google.com/apikey"
  );

  const prompt = readFileSync(options.promptPath, "utf8");
  const { reels } = JSON.parse(readFileSync(options.inputPath, "utf8"));

  if (!Array.isArray(reels) || reels.length === 0) {
    throw new Error(`No reels in ${options.inputPath}. Run scrape.mjs first.`);
  }

  console.log(`Analyzing ${reels.length} reels with ${options.concurrency} workers.\n`);

  const results = await mapWithConcurrency(reels, options.concurrency, (reel) =>
    analyzeReel({ reel, apiKey, model: options.model || env.GEMINI_MODEL, prompt })
  );

  mkdirSync(options.outDir, { recursive: true });
  const jsonPath = join(options.outDir, "analyses.json");
  const mdPath = join(options.outDir, "analysis.md");

  writeFileSync(jsonPath, JSON.stringify(results, null, 2));
  writeFileSync(mdPath, renderMarkdown(results, { promptPath: options.promptPath }));

  const ok = results.filter((r) => r.analysis).length;
  console.log(`\n${ok}/${results.length} analyzed.`);
  console.log(`Read: ${mdPath}`);
}

main().catch((error) => {
  console.error(`\nAnalysis failed: ${error.message}`);
  process.exit(1);
});
