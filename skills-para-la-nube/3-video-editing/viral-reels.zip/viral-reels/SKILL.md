---
name: viral-reels
description: Reverse-engineer competitors' best-performing Instagram Reels and turn them into new video concepts for a brand. Scrapes a list of competitor handles via Apify, ranks their recent reels by views, has Gemini watch the top ones and break down hook/retention/reward/script, then adapts them into original concepts. Use this whenever the user wants to know what's working on Instagram in their niche, asks for Reels or short-form video ideas, mentions competitor research for social content, says their reels aren't getting views, wants to analyze a creator's content, or asks what hooks or formats are going viral right now — even if they don't name Instagram or Apify explicitly.
---

# Viral Reels — competitor analysis to new concepts

Guessing at hooks is why most Reels flop. This skill replaces the guess with evidence:
find the videos that actually earned views in the user's niche in the last N days, get a
structured breakdown of *why* each one worked, then adapt those mechanics to the brand.

Pipeline: **scrape → rank by views → Gemini watches the video → you write the concepts.**

The last step is yours, not an API call. The scripts stop at the analysis; you have the
brand context and the conversation, so you're better placed to do the adaptation than a
stateless API call would be.

## Requirements

Two keys, read from the shell environment or a `.env` file in the working directory:

- `APIFY_API_TOKEN` — Instagram scraping ([console.apify.com](https://console.apify.com/account/integrations))
- `GEMINI_API_KEY` — video understanding ([aistudio.google.com/apikey](https://aistudio.google.com/apikey))

If either is missing, say which one and stop — don't try to work around it with public
web scraping, which breaks and gets blocked.

**Both steps cost real money** (Apify per actor run, Gemini per video). Confirm the handle
list and the run size with the user before executing step 2. A run of 5 creators × 3 reels
is 5 Apify runs and 15 video analyses.

## Step 1 — Collect the inputs

Ask for whatever isn't already in the conversation. Don't start scraping with half of it.

| Input | Why it matters | Default |
|---|---|---|
| Competitor handles | The whole basis of the analysis | — (required) |
| The brand + what it sells | Concepts are worthless without it | — (required) |
| Who the buyer is | Determines which hooks land | ask |
| Lookback window | Recent = current algorithm behavior | 30 days |
| Top reels per creator | More = better patterns, more cost | 3 |

Good competitor lists are 3-8 accounts that sell to the same buyer, not the biggest
accounts in the category. If the user only names one, ask for a couple more — patterns
across creators are the real output.

## Step 2 — Scrape and rank

```bash
node ~/.claude/skills/viral-reels/scripts/scrape.mjs \
  --creators handle1,handle2,handle3 \
  --days 30 --top 3 --out ./reels-run
```

Writes `./reels-run/reels.json` and prints what it found. Flags: `--max` (posts pulled per
creator before ranking, default 50), `--results-type` (Apify actor mode, default `posts`),
`--env` (path to a `.env`).

If a creator returns zero reels, the account is likely private, renamed, or posted nothing
in the window. Report it and continue with the rest rather than aborting the run.

## Step 3 — Analyze with Gemini

```bash
node ~/.claude/skills/viral-reels/scripts/analyze.mjs --input ./reels-run/reels.json
```

Downloads each reel, uploads it to the Gemini Files API, and applies the breakdown in
`references/analysis-framework.md` — concept, hook (visual/text/audio), retention
mechanisms, reward, full script, production notes. Writes `analysis.md` and `analyses.json`.

Runs 3 videos at a time and takes roughly a minute per video, so a 15-video run is around
5 minutes. Individual failures are recorded in the output rather than killing the run.

Override the model with `--model` or `GEMINI_MODEL` if the default is unavailable; point
`--prompt` at a different file to change the breakdown structure.

## Deep mode — analyze a creator's whole catalogue

When the user wants to know what *systematically* works for a creator (which hooks,
words, CTAs and themes earn reach) rather than concepts from a handful of reels, pull
the full corpus and run the quantitative layer:

```bash
node ~/.claude/skills/viral-reels/scripts/scrape.mjs \
  --creators handle --days 400 --top 500 --max 500 --out ./reels-run/full

python3 ~/.claude/skills/viral-reels/scripts/corpus-report.py \
  --input ./reels-run/full/reels.json --out ./reels-run/full
```

`corpus-report.py` compares the top band against the bottom band and writes
`corpus-report.json` with lift tables for words, hashtags, CTAs and themes. The
top-band/bottom-band contrast is the point — a word that appears in every winner is
worthless if it appears in every flop too.

Then run `references/master-prompt.md` over `reels.json`, `corpus-report.json` and (if
you analyzed videos) `analysis.md`. It is a standalone expert prompt with seven analysis
passes and a fixed output format; the user can also paste it into any other tool.

Captions are a proxy for hooks, not hooks. If the conclusions need to be about the
actual first two seconds, analyze a stratified sample of videos with `analyze.mjs` —
top performers *and* flops, so the contrast survives into the video layer.

## Step 4 — Write the concepts

Read `analysis.md`, then follow `references/concepts-framework.md`. It covers the
adaptation method (keep the retention skeleton, rewrite the hook from scratch), the output
format, and the quality bar to check concepts against before handing them over.

Save the result next to the analysis as `concepts.md` so the user has the evidence and the
output side by side.

## Working without API keys

If the user has no keys but wants help now, you can still do useful work: ask them to paste
a competitor's Reel transcript or describe the video, apply the framework in
`references/analysis-framework.md` by hand, and go straight to step 4. Say plainly that
you're working from their description rather than from the video, since you'll miss the
visual hook mechanics that way.

## Reading the results well

The single best insight is usually not a concept — it's the pattern. When you present
results, lead with what the top videos had in common (hook mechanism, format, length,
whether the founder is on camera), because that generalizes past the five videos you
happened to scrape.

Watch for a view-count outlier driven by something unrepeatable — a collab with a much
bigger account, a news moment, a paid boost. Flag it instead of teaching the user to copy it.
